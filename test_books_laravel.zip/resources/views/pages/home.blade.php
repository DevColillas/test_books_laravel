@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Home</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus egestas, urna ac consequat dictum, felis felis feugiat ex, id dictum diam ipsum eu purus. Pellentesque ac nunc a ipsum auctor pretium. Ut nec posuere arcu, ac egestas elit. Maecenas lacinia id erat ut dapibus. Cras eu rutrum ante, quis semper odio. Donec bibendum, turpis sed pretium vehicula, sem felis scelerisque purus, vel vestibulum tortor ex fringilla diam. Mauris consectetur tempus eros non porttitor. Suspendisse malesuada quis lectus nec fermentum.</p>
                <p>Maecenas pellentesque felis vitae justo blandit, id facilisis ligula porta. Duis viverra quis quam nec aliquam. Vestibulum ut egestas arcu, a tempor tellus. Mauris fermentum tincidunt odio eget luctus. Nunc eget odio laoreet, interdum dui vitae, scelerisque purus. Aenean et mi elit. Sed placerat pulvinar eleifend. Pellentesque erat augue, venenatis et rhoncus vel, fringilla cursus neque. Mauris sollicitudin libero quis est faucibus tincidunt.</p>
            </div>
        </div>
    </div>
@endsection
