
<?php

// lang/es/app.php

return [
    'headerTitleBooks' => 'Libros',
    'headerTitleContact' => 'Contacto',
    'headerTitleLanguage' => 'Lenguaje',
];