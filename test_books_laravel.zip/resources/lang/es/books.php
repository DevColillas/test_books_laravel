<?php

// lang/es/books.php

return [
    'title' => 'Libros',
    'createTitle' => 'Crear Libro',
    'create' => 'Crear Libro',
    'editTitle' => 'Editar Libro',
    'edit' => 'Editar',
    'destroy' => 'Eliminar',
    'title_placeholder' => 'Título del Libro',
    'helpTitle_placeholder' => 'Inserte la descripción del libro',
    'author_placeholder' => 'Nombre del Autor',
    'helpAuthor_placeholder' => 'Inserte el nombre del autor',
];