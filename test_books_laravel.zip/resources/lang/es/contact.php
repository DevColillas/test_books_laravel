<?php

// lang/es/conctact.php

return [
    'title' => 'Contacto',
    'email_placeholder' => 'Tu Correo Electrónico',
    'message_placeholder' => 'Tu Mensaje',
    'send' => 'Enviar Mensaje',
    'success' => 'Tu mensaje ha sido enviado con éxito.',
];