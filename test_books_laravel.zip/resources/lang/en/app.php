
<?php

// lang/en/app.php

return [
    'headerTitleBooks' => 'Books',
    'headerTitleContact' => 'Contact',
    'headerTitleLanguage' => 'Language',
];