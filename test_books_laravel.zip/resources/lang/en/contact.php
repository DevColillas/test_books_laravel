<?php

// lang/en/books.php

return [
    'title' => 'Contact',
    'email_placeholder' => 'Your Email',
    'message_placeholder' => 'Your Message',
    'send' => 'Send Message',
    'success' => 'Your message has been sent successfully.',
];