<?php

// lang/en/books.php

return [
    'title' => 'Books',
    'createTitle' => 'Create Book',
    'create' => 'Create Book',
    'editTitle' => 'Edit Book',
    'edit' => 'Edit',
    'destroy' => 'Delete',
    'title_placeholder' => 'Book Title',
    'helpTitle_placeholder' => 'Insert book description',
    'author_placeholder' => 'Author Name',
    'helpAuthor_placeholder' => 'Insert author name',
];